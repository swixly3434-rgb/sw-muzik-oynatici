package com.swplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.fragment.app.commit
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNavigationView: BottomNavigationView

    private val requestStoragePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            // Reload music if needed
            (supportFragmentManager.findFragmentByTag("home") as? HomeFragment)?.loadMusicList()
        } else {
            // Permission denied, guidance if needed
        }
    }

    private val requestOverlayPermissionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        recreate() // reload activity to refresh overlay toggle state
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> switchFragment(HomeFragment(), "home")
                R.id.navigation_player -> switchFragment(PlayerFragment(), "player")
                R.id.navigation_settings -> switchFragment(SettingsFragment(), "settings")
                else -> false
            }
        }

        // Show Home fragment at startup
        if (savedInstanceState == null) {
            bottomNavigationView.selectedItemId = R.id.navigation_home
        }
    }

    private fun switchFragment(fragment: androidx.fragment.app.Fragment, tag: String): Boolean {
        supportFragmentManager.commit {
            replace(R.id.fragmentContainer, fragment, tag)
        }
        return true
    }

    // Helpers for permission requests

    fun checkAndRequestStoragePermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestStoragePermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        } else {
            (supportFragmentManager.findFragmentByTag("home") as? HomeFragment)?.loadMusicList()
        }
    }

    fun openOverlayPermissionSettings() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName"))
            requestOverlayPermissionLauncher.launch(intent)
        }
    }
}