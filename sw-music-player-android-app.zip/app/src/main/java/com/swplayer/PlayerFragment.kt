package com.swplayer

import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class PlayerFragment : Fragment() {

    private lateinit var albumArtImageView: ImageView
    private lateinit var songTitleTextView: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playPauseButton: ImageButton
    private lateinit var prevButton: ImageButton
    private lateinit var nextButton: ImageButton
    private lateinit var repeatCheckBox: CheckBox
    private lateinit var speedSeekBar: SeekBar
    private lateinit var speedLabel: TextView

    private var handler = Handler(Looper.getMainLooper())
    private val updateInterval = 1000L

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_player, container, false)

        albumArtImageView = view.findViewById(R.id.albumArtImageView)
        songTitleTextView = view.findViewById(R.id.songTitleTextView)
        seekBar = view.findViewById(R.id.seekBar)
        playPauseButton = view.findViewById(R.id.playPauseButton)
        prevButton = view.findViewById(R.id.prevButton)
        nextButton = view.findViewById(R.id.nextButton)
        repeatCheckBox = view.findViewById(R.id.repeatCheckBox)
        speedSeekBar = view.findViewById(R.id.speedSeekBar)
        speedLabel = view.findViewById(R.id.speedLabel)

        playPauseButton.setOnClickListener {
            MusicService.togglePlayback(requireContext())
            updatePlayPauseIcon()
        }

        prevButton.setOnClickListener {
            MusicService.skipPrevious(requireContext())
            refreshUI()
        }

        nextButton.setOnClickListener {
            MusicService.skipNext(requireContext())
            refreshUI()
        }

        repeatCheckBox.setOnCheckedChangeListener { _, isChecked ->
            MusicService.setRepeat(requireContext(), isChecked)
        }

        speedSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = progress / 10f
                MusicService.setPlaybackSpeed(requireContext(), speed)
                speedLabel.text = getString(R.string.speed) + ": %.1fx".format(speed)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}

            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            var userSeeking = false
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (userSeeking) {
                    MusicService.seekTo(requireContext(), progress)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                userSeeking = false
            }
        })

        return view
    }

    override fun onResume() {
        super.onResume()
        updatePlayPauseIcon()
        refreshUI()
        handler.post(updateRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(updateRunnable)
        super.onPause()
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            val position = MusicService.getCurrentPosition(requireContext())
            val duration = MusicService.getDuration(requireContext())
            if (duration > 0) {
                seekBar.max = duration
                seekBar.progress = position
            }
            refreshUI()
            handler.postDelayed(this, updateInterval)
        }
    }

    private fun updatePlayPauseIcon() {
        if (MusicService.isPlaying(requireContext())) {
            playPauseButton.setImageResource(R.drawable.ic_pause)
            playPauseButton.contentDescription = getString(R.string.pause)
        } else {
            playPauseButton.setImageResource(R.drawable.ic_play_arrow)
            playPauseButton.contentDescription = getString(R.string.play)
        }
    }

    private fun refreshUI() {
        val currentMusic = MusicService.getCurrentMusic(requireContext())
        if (currentMusic != null) {
            songTitleTextView.text = currentMusic.title
            if (currentMusic.albumArtUri != null) {
                albumArtImageView.setImageURI(currentMusic.albumArtUri)
            } else {
                albumArtImageView.setImageResource(R.drawable.ic_music_note)
            }
        } else {
            songTitleTextView.text = ""
            albumArtImageView.setImageResource(R.drawable.ic_music_note)
        }
    }
}