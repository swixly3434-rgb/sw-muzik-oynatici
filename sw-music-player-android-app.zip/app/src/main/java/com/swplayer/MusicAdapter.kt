package com.swplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class MusicAdapter(private val onClick: (MusicItem) -> Unit) :
    ListAdapter<MusicItem, MusicAdapter.MusicViewHolder>(MusicDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent,false)
        return MusicViewHolder(view, onClick)
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class MusicViewHolder(itemView: View, val onClick: (MusicItem) -> Unit) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView = itemView.findViewById<TextView>(android.R.id.text1)
        private lateinit var currentItem: MusicItem

        init {
            itemView.setOnClickListener {
                onClick(currentItem)
            }
        }

        fun bind(item: MusicItem) {
            currentItem = item
            titleTextView.text = item.title
        }
    }
}

class MusicDiffCallback : DiffUtil.ItemCallback<MusicItem>() {
    override fun areItemsTheSame(oldItem: MusicItem, newItem: MusicItem): Boolean {
        return oldItem.uri == newItem.uri
    }

    override fun areContentsTheSame(oldItem: MusicItem, newItem: MusicItem): Boolean {
        return oldItem == newItem
    }
}