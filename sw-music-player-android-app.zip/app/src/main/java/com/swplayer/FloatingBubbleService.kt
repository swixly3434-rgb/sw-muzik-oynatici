package com.swplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import de.hdodenhof.circleimageview.CircleImageView

/**
 * Service to display draggable floating bubble with music controls above other apps.
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: View
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var bubbleAlbumArt: CircleImageView
    private lateinit var bubbleSongTitle: TextView
    private lateinit var bubbleRewindButton: ImageButton
    private lateinit var bubblePlayPauseButton: ImageButton
    private lateinit var bubbleForwardButton: ImageButton
    private lateinit var bubbleNextButton: ImageButton
    private lateinit var bubbleVolumeSeekBar: SeekBar

    private var isPlaying = false

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "swplayer_bubble_channel"
        private const val NOTIFICATION_ID = 999
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)

        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)
        bubbleAlbumArt = bubbleView.findViewById(R.id.bubbleAlbumArt)
        bubbleSongTitle = bubbleView.findViewById(R.id.bubbleSongTitle)
        bubbleRewindButton = bubbleView.findViewById(R.id.bubbleRewindButton)
        bubblePlayPauseButton = bubbleView.findViewById(R.id.bubblePlayPauseButton)
        bubbleForwardButton = bubbleView.findViewById(R.id.bubbleForwardButton)
        bubbleNextButton = bubbleView.findViewById(R.id.bubbleNextButton)
        bubbleVolumeSeekBar = bubbleView.findViewById(R.id.bubbleVolumeSeekBar)

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        layoutParams!!.gravity = Gravity.TOP or Gravity.START
        layoutParams!!.x = 100
        layoutParams!!.y = 100

        windowManager.addView(bubbleView, layoutParams)

        setBubbleTouchListener()

        refreshUI()

        bubbleRewindButton.setOnClickListener {
            MusicService.seekTo(applicationContext, (MusicService.getCurrentPosition(applicationContext) - 10_000).coerceAtLeast(0))
        }

        bubblePlayPauseButton.setOnClickListener {
            MusicService.togglePlayback(applicationContext)
            refreshUI()
        }

        bubbleForwardButton.setOnClickListener {
            MusicService.seekTo(applicationContext, (MusicService.getCurrentPosition(applicationContext) + 10_000)
                .coerceAtMost(MusicService.getDuration(applicationContext)))
        }

        bubbleNextButton.setOnClickListener {
            MusicService.skipNext(applicationContext)
            refreshUI()
        }

        bubbleVolumeSeekBar.max = 100
        bubbleVolumeSeekBar.progress = 50
        bubbleVolumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val volume = progress / 100f
                MusicService.setVolume(applicationContext, volume)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        if (this::windowManager.isInitialized && this::bubbleView.isInitialized) {
            windowManager.removeView(bubbleView)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun refreshUI() {
        val currentMusic = MusicService.getCurrentMusic(applicationContext)
        if (currentMusic != null) {
            bubbleSongTitle.text = currentMusic.title
            if (currentMusic.albumArtUri != null) {
                bubbleAlbumArt.setImageURI(currentMusic.albumArtUri)
            } else {
                bubbleAlbumArt.setImageResource(R.drawable.ic_music_note)
            }
        } else {
            bubbleSongTitle.text = ""
            bubbleAlbumArt.setImageResource(R.drawable.ic_music_note)
        }
        isPlaying = MusicService.isPlaying(applicationContext)

        bubblePlayPauseButton.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play_arrow)
        bubblePlayPauseButton.contentDescription = if (isPlaying) getString(R.string.pause) else getString(R.string.play)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID, "SW Player Bubble", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.bubble_controls))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun setBubbleTouchListener() {
        bubbleView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (event == null) return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams!!.x
                        initialY = layoutParams!!.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        layoutParams!!.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams!!.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(bubbleView, layoutParams)
                        return true
                    }
                }
                return false
            }
        })
    }
}