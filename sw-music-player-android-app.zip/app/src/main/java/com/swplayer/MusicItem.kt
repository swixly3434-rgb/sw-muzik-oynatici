package com.swplayer

import android.net.Uri

data class MusicItem(
    val uri: Uri,
    val title: String,
    val albumArtUri: Uri? = null
)