package com.swplayer

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore

object MusicRepository {
    private val musicList = mutableListOf<MusicItem>()

    fun getAllMusic(context: Context): List<MusicItem> {
        if (musicList.isNotEmpty()) return musicList

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.ALBUM_ID
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC}!=0"

        val cursor: Cursor? = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection, selection, null,
            "${MediaStore.Audio.Media.DISPLAY_NAME} ASC"
        )

        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val albumIdCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val title = it.getString(nameCol)
                val albumId = it.getLong(albumIdCol)
                val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                val albumArtUri = Uri.parse("content://media/external/audio/albumart/$albumId")

                musicList.add(MusicItem(contentUri, title, albumArtUri))
            }
        }
        return musicList
    }

    fun addMusicFromUri(context: Context, uri: Uri): MusicItem? {
        // Simple add if not already present
        if (!musicList.any { it.uri == uri }) {
            // Extract title from ContentResolver or fallback
            val title = context.contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val displayNameIndex = it.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                    if (displayNameIndex != -1) {
                        it.getString(displayNameIndex)
                    } else null
                } else null
            } ?: uri.lastPathSegment ?: "Unknown"

            val item = MusicItem(uri, title, null)
            musicList.add(item)
            return item
        }
        return null
    }
}