package com.swplayer

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    private lateinit var languageRadioGroup: RadioGroup
    private lateinit var radioEnglish: RadioButton
    private lateinit var radioTurkish: RadioButton
    private lateinit var permissionsButton: Button
    private lateinit var overlayToggle: CheckBox

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        languageRadioGroup = view.findViewById(R.id.languageRadioGroup)
        radioEnglish = view.findViewById(R.id.radioEnglish)
        radioTurkish = view.findViewById(R.id.radioTurkish)
        permissionsButton = view.findViewById(R.id.permissionsButton)
        overlayToggle = view.findViewById(R.id.overlayToggle)

        // Load saved language preference or default English
        val currentLang = LocaleHelper.getLanguage(requireContext())
        if (currentLang == "tr") radioTurkish.isChecked = true else radioEnglish.isChecked = true

        languageRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.radioEnglish -> LocaleHelper.setLocale(requireContext(), "en")
                R.id.radioTurkish -> LocaleHelper.setLocale(requireContext(), "tr")
            }
            activity?.recreate() // reload to apply locale
        }

        permissionsButton.setOnClickListener {
            (activity as? MainActivity)?.openOverlayPermissionSettings()
        }

        overlayToggle.isChecked = OverlayPermissionHelper.isOverlayEnabled(requireContext())
        overlayToggle.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Request overlay permission via MainActivity
                (activity as? MainActivity)?.openOverlayPermissionSettings()
            } else {
                // Stop FloatingBubbleService if running
                OverlayPermissionHelper.disableOverlay(requireContext())
            }
        }

        return view
    }
}