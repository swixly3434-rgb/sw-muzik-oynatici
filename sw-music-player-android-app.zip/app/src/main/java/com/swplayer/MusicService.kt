package com.swplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Service that manages MediaPlayer playback in foreground.
 * Handles play, pause, skipping, repeat, speed control.
 */
class MusicService : Service() {

    companion object {
        const val CHANNEL_ID = "swplayer_music_channel"
        private var mediaPlayer: MediaPlayer? = null
        private var playlist = mutableListOf<MusicItem>()
        private var currentIndex = 0
        private var isRepeat = false
        private var playbackSpeed = 1.0f

        fun playMusic(context: Context, music: MusicItem) {
            val serviceIntent = Intent(context, MusicService::class.java)
            serviceIntent.action = "ACTION_PLAY"
            serviceIntent.putExtra("music_uri", music.uri.toString())
            context.startForegroundService(serviceIntent)
          
            // Update playlist index to the one selected
            currentIndex = playlist.indexOfFirst { it.uri == music.uri }
            if (currentIndex == -1) {
                playlist.add(music)
                currentIndex = playlist.size - 1
            }
        }

        fun togglePlayback(context: Context) {
            val intent = Intent(context, MusicService::class.java).apply { action = "ACTION_TOGGLE" }
            context.startService(intent)
        }

        fun skipNext(context: Context) {
            val intent = Intent(context, MusicService::class.java).apply { action = "ACTION_NEXT" }
            context.startService(intent)
        }

        fun skipPrevious(context: Context) {
            val intent = Intent(context, MusicService::class.java).apply { action = "ACTION_PREVIOUS" }
            context.startService(intent)
        }

        fun setRepeat(context: Context, repeat: Boolean) {
            isRepeat = repeat
        }

        fun setPlaybackSpeed(context: Context, speed: Float) {
            playbackSpeed = speed
            mediaPlayer?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    it.playbackParams = it.playbackParams.setSpeed(speed)
                }
            }
        }

        fun getCurrentPosition(context: Context): Int {
            return mediaPlayer?.currentPosition ?: 0
        }

        fun getDuration(context: Context): Int {
            return mediaPlayer?.duration ?: 0
        }

        fun seekTo(context: Context, pos: Int) {
            mediaPlayer?.seekTo(pos)
        }

        fun isPlaying(context: Context): Boolean {
            return mediaPlayer?.isPlaying ?: false
        }

        fun getCurrentMusic(context: Context): MusicItem? {
            return if (currentIndex in playlist.indices) playlist[currentIndex] else null
        }

        private fun stopPlayback() {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        when(action) {
            "ACTION_PLAY" -> {
                val uriString = intent.getStringExtra("music_uri")
                val uri = uriString?.let { Uri.parse(it) }
                if (uri != null) {
                    play(uri)
                }
            }
            "ACTION_TOGGLE" -> {
                togglePlayPause()
            }
            "ACTION_NEXT" -> {
                playNext()
            }
            "ACTION_PREVIOUS" -> {
                playPrevious()
            }
        }
        return START_STICKY
    }

    private fun play(uri: Uri) {
        stopPlayback()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(applicationContext, uri)
            isLooping = isRepeat
            setOnPreparedListener { start(); updateNotification() }
            setOnCompletionListener {
                if (!isRepeat) playNext() else start()
            }
            prepareAsync()
        }
        updateNotification()
    }

    private fun playNext() {
        currentIndex = (currentIndex + 1) % playlist.size
        val nextMusic = playlist.getOrNull(currentIndex) ?: return
        play(nextMusic.uri)
    }

    private fun playPrevious() {
        currentIndex = if (currentIndex - 1 < 0) playlist.size - 1 else currentIndex - 1
        val prevMusic = playlist.getOrNull(currentIndex) ?: return
        play(prevMusic.uri)
    }

    private fun togglePlayPause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
            } else {
                it.start()
            }
            updateNotification()
        }
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SW Music Player",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun updateNotification() {
        val currentMusic = getCurrentMusic(this)
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentMusic?.title ?: "SW Music Player")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(mediaPlayer?.isPlaying == true)
            .setOnlyAlertOnce(true)

        startForeground(1, builder.build())
    }
}