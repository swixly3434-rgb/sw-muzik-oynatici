package com.swplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import java.util.*

object LocaleHelper {

    fun setLocale(context: Context, langCode: String) {
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = context.resources.configuration
        config.setLocale(locale)
        context.resources.updateConfiguration(config, context.resources.displayMetrics)
        // Persist language to shared prefs if needed
        PreferencesHelper.saveLanguage(context, langCode)
    }

    fun getLanguage(context: Context): String {
        val prefs = context.getSharedPreferences("swplayer_prefs", Context.MODE_PRIVATE)
        return prefs.getString("app_lang", Locale.getDefault().language) ?: "en"
    }
}

object PreferencesHelper {

    fun saveLanguage(context: Context, langCode: String) {
        val prefs = context.getSharedPreferences("swplayer_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("app_lang", langCode).apply()
    }
}

object OverlayPermissionHelper {

    fun isOverlayEnabled(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun disableOverlay(context: Context) {
        // Stop FloatingBubbleService if running
        val intent = Intent(context, FloatingBubbleService::class.java)
        context.stopService(intent)
    }
}