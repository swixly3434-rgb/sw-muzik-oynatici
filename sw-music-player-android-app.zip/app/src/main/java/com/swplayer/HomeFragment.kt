package com.swplayer

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeFragment : Fragment() {

    private lateinit var musicRecyclerView: RecyclerView
    private lateinit var addMusicButton: FloatingActionButton
    private val musicAdapter = MusicAdapter { musicItem ->
        // Play selected music
        MusicService.playMusic(requireContext(), musicItem)
    }
    private val pickMusicLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri>? ->
        if (uris == null || uris.isEmpty()) return@registerForActivityResult
        val added = mutableListOf<MusicItem>()
        uris.forEach { uri ->
            val music = MusicRepository.addMusicFromUri(requireContext(), uri)
            if (music != null) added.add(music)
        }
        if (added.isNotEmpty()) {
            Toast.makeText(requireContext(), "Added ${added.size} music(s)", Toast.LENGTH_SHORT).show()
            loadMusicList()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        musicRecyclerView = view.findViewById(R.id.musicRecyclerView)
        addMusicButton = view.findViewById(R.id.addMusicButton)

        musicRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        musicRecyclerView.adapter = musicAdapter

        addMusicButton.setOnClickListener {
            pickMusicLauncher.launch(arrayOf("audio/mpeg", "audio/mp3"))
        }

        loadMusicList()

        return view
    }

    fun loadMusicList() {
        if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.READ_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            (activity as? MainActivity)?.checkAndRequestStoragePermission()
            return
        }

        val musicList = MusicRepository.getAllMusic(requireContext())
        musicAdapter.submitList(musicList)
    }
}