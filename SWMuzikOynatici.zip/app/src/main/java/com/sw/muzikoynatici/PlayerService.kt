package com.sw.muzikoynatici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.random.Random

/**
 * Müziği çalan, bildirimi yöneten ve baloncuğu (Overlay) gösteren servis.
 * Uygulama kapansa bile müzik ve baloncuk çalışmaya devam eder.
 */
class PlayerService : Service(), AudioManager.OnAudioFocusChangeListener {

    interface Listener {
        fun onChanged()
    }

    inner class LocalBinder : Binder() {
        fun getService(): PlayerService = this@PlayerService
    }

    companion object {
        const val CHANNEL_ID = "sw_playback"
        const val NOTIF_ID = 1001
        const val ACTION_TOGGLE = "com.sw.muzikoynatici.action.TOGGLE"
        const val ACTION_NEXT = "com.sw.muzikoynatici.action.NEXT"
        const val ACTION_PREV = "com.sw.muzikoynatici.action.PREV"
        const val ACTION_STOP = "com.sw.muzikoynatici.action.STOP"

        const val REPEAT_OFF = 0
        const val REPEAT_ALL = 1
        const val REPEAT_ONE = 2

        val SPEEDS = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    }

    private val binder = LocalBinder()
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var overlay: Overlay

    private val audioManager: AudioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val notificationManager: NotificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }
    private val defaultNotifIcon: Bitmap by lazy {
        val raw: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.cover)
        if (raw != null) square(raw, 256) else Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    }

    private var player: MediaPlayer? = null
    private var prepared = false
    private var wantPlay = false
    private var resumeOnFocus = false
    private var ducked = false
    private var started = false
    private var focusRequest: AudioFocusRequest? = null
    private var notifIcon: Bitmap? = null
    private val history = ArrayList<String>()

    var current: Song? = null
        private set
    var art: Bitmap? = null
        private set
    var playing = false
        private set
    var shuffle = false
        private set
    var repeatMode = REPEAT_OFF
        private set
    var speed = 1.0f
        private set
    var volume = 1.0f
        private set
    var bubbleEnabled = false
        private set
    var sleepEndAt = 0L
        private set

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("sw_prefs", Context.MODE_PRIVATE)
        shuffle = prefs.getBoolean("shuffle", false)
        repeatMode = prefs.getInt("repeat", REPEAT_OFF)
        speed = prefs.getFloat("speed", 1.0f)
        volume = prefs.getFloat("volume", 1.0f)
        bubbleEnabled = prefs.getBoolean("bubble", false)

        createChannel()
        overlay = Overlay(this)
        startForegroundCompat()
        registerNoisy()

        if (bubbleEnabled) {
            if (Settings.canDrawOverlays(this)) {
                overlay.show()
            } else {
                bubbleEnabled = false
                prefs.edit().putBoolean("bubble", false).apply()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        started = true
        startForegroundCompat()
        when (intent?.action) {
            ACTION_TOGGLE -> toggle()
            ACTION_NEXT -> next()
            ACTION_PREV -> prev()
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        maybeStop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlay.onConfigChanged()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            unregisterReceiver(noisyReceiver)
        } catch (e: Exception) {
        }
        overlay.hide()
        releasePlayer()
        abandonFocus()
        super.onDestroy()
    }

    /** Müzik çalmıyorsa ve baloncuk kapalıysa servisi tamamen kapatır. */
    fun maybeStop() {
        if (!playing && !bubbleEnabled) shutdown()
    }

    private fun shutdown() {
        wantPlay = false
        resumeOnFocus = false
        releasePlayer()
        playing = false
        abandonFocus()
        handler.removeCallbacks(sleepRunnable)
        sleepEndAt = 0L
        bubbleEnabled = false
        prefs.edit().putBoolean("bubble", false).apply()
        overlay.hide()
        started = false
        for (l in listeners) l.onChanged()
        stopForeground(Service.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun ensureStarted() {
        if (!started) {
            started = true
            ContextCompat.startForegroundService(this, Intent(this, PlayerService::class.java))
        }
    }

    // ------------------------------------------------------------------ dinleyiciler

    fun addListener(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun notifyUi() {
        overlay.refresh()
        for (l in listeners) l.onChanged()
    }

    private fun updateAll() {
        updateNotification()
        notifyUi()
    }

    // ------------------------------------------------------------------ çalma kontrolleri

    fun playSong(song: Song, pushHistory: Boolean = true) {
        ensureStarted()
        val cur = current
        if (pushHistory && cur != null && cur.uri != song.uri) {
            history.add(cur.uri)
            if (history.size > 50) history.removeAt(0)
        }
        releasePlayer()
        current = song
        art = null
        notifIcon = null
        wantPlay = true
        playing = false
        resumeOnFocus = false
        loadArt(song)

        val mp = MediaPlayer()
        player = mp
        try {
            mp.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK)
            mp.setAudioAttributes(audioAttrs())
            mp.setDataSource(applicationContext, Uri.parse(song.uri))
            applyVolume()
            mp.isLooping = repeatMode == REPEAT_ONE
            mp.setOnPreparedListener { p ->
                if (p === player) {
                    prepared = true
                    if (wantPlay) startPlayback() else updateAll()
                }
            }
            mp.setOnCompletionListener { p ->
                if (p === player) onTrackComplete()
            }
            mp.setOnErrorListener { p, _, _ ->
                if (p === player) onPlayError()
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            e.printStackTrace()
            onPlayError()
            return
        }
        updateAll()
    }

    private fun startPlayback() {
        val mp = player ?: return
        if (!prepared) {
            wantPlay = true
            return
        }
        if (!requestFocus()) {
            // başka bir uygulama (telefon görüşmesi vb.) sesi tutuyor
            playing = false
            updateAll()
            return
        }
        try {
            mp.start()
            playing = true
            wantPlay = true
            applyVolume()
            applySpeed()
        } catch (e: IllegalStateException) {
            e.printStackTrace()
            onPlayError()
            return
        }
        updateAll()
    }

    fun resume() {
        ensureStarted()
        if (player == null) {
            val c = current
            if (c != null) {
                playSong(c, false)
                return
            }
            val list = Library.songs
            if (list.isNotEmpty()) playSong(list[0])
            return
        }
        wantPlay = true
        startPlayback()
    }

    fun pause() {
        wantPlay = false
        resumeOnFocus = false
        pauseInternal()
        abandonFocus()
    }

    private fun pauseInternal() {
        try {
            val p = player
            if (p != null && prepared && p.isPlaying) p.pause()
        } catch (e: IllegalStateException) {
            e.printStackTrace()
        }
        playing = false
        updateAll()
    }

    fun toggle() {
        if (playing) pause() else resume()
    }

    private fun indexOfCurrent(list: List<Song>): Int {
        val c = current ?: return -1
        return list.indexOfFirst { it.uri == c.uri }
    }

    fun next() {
        val list = Library.songs
        if (list.isEmpty()) return
        val cur = indexOfCurrent(list)
        val idx = if (shuffle && list.size > 1) {
            var r = Random.nextInt(list.size)
            while (r == cur) r = Random.nextInt(list.size)
            r
        } else {
            (cur + 1) % list.size
        }
        playSong(list[idx])
    }

    fun prev() {
        if (position() > 3000) {
            seekTo(0)
            return
        }
        val list = Library.songs
        while (history.isNotEmpty()) {
            val uri = history.removeAt(history.size - 1)
            val s = list.firstOrNull { it.uri == uri }
            if (s != null) {
                playSong(s, false)
                return
            }
        }
        if (list.isEmpty()) return
        val cur = indexOfCurrent(list)
        val idx = if (cur <= 0) list.size - 1 else cur - 1
        playSong(list[idx], false)
    }

    private fun onTrackComplete() {
        // "Tek parçayı tekrarla" modunda MediaPlayer kendisi başa sarar (isLooping), buraya gelmez.
        val list = Library.songs
        val cur = indexOfCurrent(list)
        val hasNext = cur >= 0 && cur < list.size - 1
        if (repeatMode == REPEAT_ALL || shuffle || hasNext) {
            next()
        } else {
            // listenin sonu, tekrar kapalı: başa sarıp dur
            try {
                player?.seekTo(0)
            } catch (e: Exception) {
            }
            playing = false
            wantPlay = false
            abandonFocus()
            updateAll()
        }
    }

    private fun onPlayError() {
        Toast.makeText(
            applicationContext,
            LocaleHelper.wrap(applicationContext).getString(R.string.play_error),
            Toast.LENGTH_SHORT
        ).show()
        releasePlayer()
        playing = false
        wantPlay = false
        updateAll()
    }

    private fun releasePlayer() {
        prepared = false
        val p = player
        player = null
        if (p != null) {
            try {
                p.setOnPreparedListener(null)
                p.setOnCompletionListener(null)
                p.setOnErrorListener(null)
                p.release()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ------------------------------------------------------------------ sarma / konum

    fun skip(deltaMs: Int) {
        val p = player ?: return
        if (!prepared) return
        try {
            val d = p.duration
            val t = (p.currentPosition + deltaMs).coerceIn(0, if (d > 0) d else Int.MAX_VALUE)
            p.seekTo(t)
        } catch (e: IllegalStateException) {
            e.printStackTrace()
        }
    }

    fun seekTo(ms: Int) {
        val p = player ?: return
        if (!prepared) return
        try {
            p.seekTo(ms)
        } catch (e: IllegalStateException) {
            e.printStackTrace()
        }
    }

    fun position(): Int {
        return try {
            if (prepared) (player?.currentPosition ?: 0) else 0
        } catch (e: Exception) {
            0
        }
    }

    fun duration(): Int {
        val d = try {
            if (prepared) (player?.duration ?: 0) else 0
        } catch (e: Exception) {
            0
        }
        if (d > 0) return d
        return (current?.duration ?: 0L).toInt()
    }

    // ------------------------------------------------------------------ ses / hız / mod

    fun setVolume(v: Float) {
        volume = v.coerceIn(0f, 1f)
        prefs.edit().putFloat("volume", volume).apply()
        applyVolume()
        notifyUi()
    }

    private fun applyVolume() {
        val v = if (ducked) volume * 0.3f else volume
        try {
            player?.setVolume(v, v)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cycleSpeed() {
        var i = SPEEDS.indexOfFirst { it == speed }
        if (i < 0) i = 2
        speed = SPEEDS[(i + 1) % SPEEDS.size]
        prefs.edit().putFloat("speed", speed).apply()
        if (playing) applySpeed()
        notifyUi()
    }

    private fun applySpeed() {
        val p = player ?: return
        if (!prepared) return
        try {
            p.playbackParams = PlaybackParams().setSpeed(speed)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleShuffle() {
        shuffle = !shuffle
        prefs.edit().putBoolean("shuffle", shuffle).apply()
        notifyUi()
    }

    fun cycleRepeat() {
        repeatMode = (repeatMode + 1) % 3
        prefs.edit().putInt("repeat", repeatMode).apply()
        try {
            player?.isLooping = repeatMode == REPEAT_ONE
        } catch (e: Exception) {
            e.printStackTrace()
        }
        notifyUi()
    }

    // ------------------------------------------------------------------ uyku zamanlayıcı

    private val sleepRunnable = Runnable {
        sleepEndAt = 0L
        pause()
    }

    fun setSleepTimer(minutes: Int) {
        handler.removeCallbacks(sleepRunnable)
        if (minutes <= 0) {
            sleepEndAt = 0L
        } else {
            val ms = minutes * 60_000L
            sleepEndAt = android.os.SystemClock.elapsedRealtime() + ms
            handler.postDelayed(sleepRunnable, ms)
        }
        notifyUi()
    }

    fun sleepActive(): Boolean = sleepEndAt != 0L

    // ------------------------------------------------------------------ baloncuk

    fun setBubbleEnabled(on: Boolean): Boolean {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                bubbleEnabled = false
                prefs.edit().putBoolean("bubble", false).apply()
                notifyUi()
                return false
            }
            bubbleEnabled = true
            prefs.edit().putBoolean("bubble", true).apply()
            ensureStarted()
            overlay.show()
        } else {
            bubbleEnabled = false
            prefs.edit().putBoolean("bubble", false).apply()
            overlay.hide()
        }
        notifyUi()
        return bubbleEnabled
    }

    fun onLanguageChanged() {
        createChannel()
        updateNotification()
        notifyUi()
    }

    // ------------------------------------------------------------------ kapak resmi

    private fun loadArt(song: Song) {
        Art.load(applicationContext, song.uri, 512) { bmp ->
            if (current?.uri == song.uri) {
                art = bmp
                notifIcon = if (bmp != null) square(bmp, 256) else null
                updateAll()
            }
        }
    }

    private fun square(b: Bitmap, size: Int): Bitmap {
        val s = minOf(b.width, b.height)
        val x = (b.width - s) / 2
        val y = (b.height - s) / 2
        val cropped = Bitmap.createBitmap(b, x, y, s, s)
        return Bitmap.createScaledBitmap(cropped, size, size, true)
    }

    // ------------------------------------------------------------------ ses odağı

    private fun audioAttrs(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

    private fun requestFocus(): Boolean {
        val req: AudioFocusRequest = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(audioAttrs())
            .setOnAudioFocusChangeListener(this)
            .build()
            .also { focusRequest = it }
        return audioManager.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val r = focusRequest
        if (r != null) {
            try {
                audioManager.abandonAudioFocusRequest(r)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onAudioFocusChange(change: Int) {
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                resumeOnFocus = false
                wantPlay = false
                pauseInternal()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                resumeOnFocus = playing
                pauseInternal()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                ducked = true
                applyVolume()
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                ducked = false
                applyVolume()
                if (resumeOnFocus) {
                    resumeOnFocus = false
                    startPlayback()
                }
            }
        }
    }

    // Kulaklık çıkınca müziği durdur
    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && playing) pause()
        }
    }

    private fun registerNoisy() {
        val f = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(noisyReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(noisyReceiver, f)
        }
    }

    // ------------------------------------------------------------------ bildirim

    private fun createChannel() {
        val lc = LocaleHelper.wrap(applicationContext)
        val ch = NotificationChannel(
            CHANNEL_ID,
            lc.getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        ch.setShowBadge(false)
        notificationManager.createNotificationChannel(ch)
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateNotification() {
        if (!started) return
        try {
            notificationManager.notify(NOTIF_ID, buildNotification())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun actionIntent(action: String, code: Int): PendingIntent {
        val i = Intent(this, PlayerService::class.java).setAction(action)
        return PendingIntent.getForegroundService(
            this, code, i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun notifAction(icon: Int, label: String, action: String, code: Int): Notification.Action =
        Notification.Action.Builder(
            Icon.createWithResource(this, icon), label, actionIntent(action, code)
        ).build()

    private fun buildNotification(): Notification {
        val lc = LocaleHelper.wrap(applicationContext)
        val song = current
        val title = song?.title ?: lc.getString(R.string.app_name)
        val text = if (song != null) song.displayArtist(lc) else lc.getString(R.string.select_song)

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggle = if (playing) {
            notifAction(R.drawable.ic_pause, lc.getString(R.string.notif_pause), ACTION_TOGGLE, 2)
        } else {
            notifAction(R.drawable.ic_play, lc.getString(R.string.notif_play), ACTION_TOGGLE, 2)
        }

        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setLargeIcon(notifIcon ?: defaultNotifIcon)
            .setContentIntent(openApp)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setOngoing(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(notifAction(R.drawable.ic_prev, lc.getString(R.string.notif_prev), ACTION_PREV, 1))
            .addAction(toggle)
            .addAction(notifAction(R.drawable.ic_next, lc.getString(R.string.notif_next), ACTION_NEXT, 3))
            .addAction(notifAction(R.drawable.ic_close, lc.getString(R.string.notif_close), ACTION_STOP, 4))
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }
}
