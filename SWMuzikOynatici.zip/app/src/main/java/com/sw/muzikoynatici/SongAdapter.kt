package com.sw.muzikoynatici

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.roundToInt

class SongAdapter(
    private val onClick: (Song) -> Unit,
    private val onLongClick: (Song) -> Unit
) : RecyclerView.Adapter<SongAdapter.VH>() {

    var items: List<Song> = emptyList()
        private set
    private var currentUri: String? = null

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.item_thumb)
        val title: TextView = v.findViewById(R.id.item_title)
        val artist: TextView = v.findViewById(R.id.item_artist)
        val dur: TextView = v.findViewById(R.id.item_dur)
    }

    fun submit(list: List<Song>) {
        items = list
        notifyDataSetChanged()
    }

    fun setCurrent(uri: String?) {
        if (uri != currentUri) {
            currentUri = uri
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val ctx = holder.itemView.context

        holder.title.text = s.title
        holder.artist.text = s.displayArtist(ctx)
        holder.dur.text = formatTime(s.duration)

        val isCurrent = s.uri == currentUri
        holder.title.setTextColor(
            ContextCompat.getColor(ctx, if (isCurrent) R.color.accent else R.color.text_primary)
        )

        // Önce müzik notası göster, kapak resmi gelince değiştir
        val pad = (14 * ctx.resources.displayMetrics.density).roundToInt()
        holder.thumb.tag = s.uri
        holder.thumb.scaleType = ImageView.ScaleType.CENTER_INSIDE
        holder.thumb.setPadding(pad, pad, pad, pad)
        holder.thumb.setImageResource(R.drawable.ic_music_note)

        Art.load(ctx, s.uri, 128) { bmp ->
            if (bmp != null && holder.thumb.tag == s.uri) {
                holder.thumb.setPadding(0, 0, 0, 0)
                holder.thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                holder.thumb.setImageBitmap(bmp)
            }
        }

        holder.itemView.setOnClickListener { onClick(s) }
        holder.itemView.setOnLongClickListener {
            if (s.added) {
                onLongClick(s)
                true
            } else {
                false
            }
        }
    }
}
