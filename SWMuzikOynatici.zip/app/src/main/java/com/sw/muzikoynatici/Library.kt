package com.sw.muzikoynatici

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

object Library {

    private const val PREF = "sw_prefs"
    private const val KEY_ADDED = "added"

    @Volatile
    var songs: List<Song> = emptyList()

    fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioPermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

    /** Cihazdaki tüm MP3'leri + kullanıcının elle eklediklerini yükler. Arka plan thread'inde çağır. */
    fun load(ctx: Context): List<Song> {
        val result = ArrayList<Song>()
        if (hasAudioPermission(ctx)) {
            try {
                queryMediaStore(ctx, result)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        for (s in loadAdded(ctx)) {
            val dup = result.any {
                it.uri == s.uri || (s.size > 0 && it.name == s.name && it.size == s.size)
            }
            if (!dup) result.add(s)
        }
        result.sortWith(Comparator<Song> { a, b -> a.title.compareTo(b.title, ignoreCase = true) })
        songs = result
        return result
    }

    private fun queryMediaStore(ctx: Context, out: MutableList<Song>) {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE
        )
        val selection = "(" + MediaStore.Audio.Media.MIME_TYPE + " = ? OR " +
                MediaStore.Audio.Media.DISPLAY_NAME + " LIKE ?)"
        val args = arrayOf("audio/mpeg", "%.mp3")

        ctx.contentResolver.query(collection, projection, selection, args, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)

            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val name = c.getString(nameCol) ?: ""
                val rawTitle = c.getString(titleCol)
                val title = if (rawTitle.isNullOrBlank()) name.substringBeforeLast('.') else rawTitle
                var artist = c.getString(artistCol) ?: ""
                if (artist == "<unknown>") artist = ""
                val uri = ContentUris.withAppendedId(collection, id)
                out.add(
                    Song(
                        uri.toString(), title, artist,
                        c.getLong(durCol), name, c.getLong(sizeCol), false
                    )
                )
            }
        }
    }

    // ---------- Elle eklenen müzikler ----------

    private fun loadAdded(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val json = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_ADDED, null) ?: return out
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Song(
                        o.getString("uri"), o.optString("title"), o.optString("artist"),
                        o.optLong("duration"), o.optString("name"), o.optLong("size"), true
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return out
    }

    private fun saveAdded(ctx: Context, list: List<Song>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("uri", s.uri)
            o.put("title", s.title)
            o.put("artist", s.artist)
            o.put("duration", s.duration)
            o.put("name", s.name)
            o.put("size", s.size)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY_ADDED, arr.toString()).apply()
    }

    /** Dosya seçiciden gelen müzikleri listeye ekler. Kaç tanesinin yeni eklendiğini döndürür. Arka plan thread'inde çağır. */
    fun addSongs(ctx: Context, uris: List<Uri>): Int {
        val current = ArrayList<Song>(loadAdded(ctx))
        var count = 0
        for (uri in uris) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // bazı sağlayıcılar kalıcı izin vermez, sorun değil
            }

            var name = ""
            var size = 0L
            try {
                ctx.contentResolver.query(
                    uri,
                    arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: ""
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val key = uri.toString()
            val exists = (songs + current).any {
                it.uri == key || (name.isNotEmpty() && size > 0 && it.name == name && it.size == size)
            }
            if (exists) continue

            var title = ""
            var artist = ""
            var duration = 0L
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
                artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
                duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                }
            }
            if (title.isBlank()) {
                title = if (name.isNotBlank()) name.substringBeforeLast('.') else (uri.lastPathSegment ?: "Music")
            }
            current.add(Song(key, title, artist, duration, name, size, true))
            count++
        }
        if (count > 0) saveAdded(ctx, current)
        return count
    }

    fun removeAdded(ctx: Context, uri: String) {
        saveAdded(ctx, loadAdded(ctx).filter { it.uri != uri })
    }
}
