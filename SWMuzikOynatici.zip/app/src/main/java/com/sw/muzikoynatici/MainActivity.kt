package com.sw.muzikoynatici

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), PlayerService.Listener {

    private var service: PlayerService? = null
    private var bound = false
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var adapter: SongAdapter

    // sayfalar
    private lateinit var nav: BottomNavigationView
    private lateinit var pageHome: View
    private lateinit var pagePlayer: View
    private lateinit var pageSettings: View

    // ana menü
    private lateinit var rv: RecyclerView
    private lateinit var fab: FloatingActionButton
    private lateinit var emptyBox: LinearLayout
    private lateinit var tvEmpty: TextView
    private lateinit var btnGrant: Button
    private lateinit var tvCount: TextView

    // oynatıcı
    private lateinit var ivArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var seek: SeekBar
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var btnRew: View
    private lateinit var btnFwd: View
    private lateinit var btnPrev: ImageView
    private lateinit var btnPlay: ImageView
    private lateinit var btnNext: ImageView
    private lateinit var btnShuffle: ImageView
    private lateinit var btnRepeat: ImageView
    private lateinit var btnSpeed: TextView
    private lateinit var btnSleep: ImageView
    private lateinit var seekVol: SeekBar
    private lateinit var swOverlay: SwitchMaterial

    // ayarlar
    private lateinit var rgLang: RadioGroup
    private lateinit var rbTr: RadioButton
    private lateinit var rbEn: RadioButton
    private lateinit var rowAccess: View
    private lateinit var tvVersion: TextView

    private var tab = 0
    private var userSeeking = false
    private var updatingUi = false
    private var pendingOverlay = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as PlayerService.LocalBinder).getService()
            service = s
            s.addListener(this@MainActivity)
            refreshUi()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            prefs.edit().putBoolean("perm_asked", true).apply()
            loadLibrary()
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) addSongs(uris)
        }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("sw_prefs", Context.MODE_PRIVATE)

        bindViews()
        setupHome()
        setupPlayer()
        setupSettings()

        nav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> showTab(0)
                R.id.nav_player -> showTab(1)
                else -> showTab(2)
            }
            true
        }
        val startTab = savedInstanceState?.getInt("tab", 0) ?: 0
        showTab(startTab)
        nav.selectedItemId = when (startTab) {
            1 -> R.id.nav_player
            2 -> R.id.nav_settings
            else -> R.id.nav_home
        }

        val i = Intent(this, PlayerService::class.java)
        ContextCompat.startForegroundService(this, i)
        bound = bindService(i, connection, Context.BIND_AUTO_CREATE)

        askPermissions()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        loadLibrary()
        ui.removeCallbacks(ticker)
        ui.post(ticker)
        if (pendingOverlay) {
            pendingOverlay = false
            if (Settings.canDrawOverlays(this)) service?.setBubbleEnabled(true)
        }
        refreshUi()
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        val s = service
        if (s != null) {
            s.removeListener(this)
            if (isFinishing) s.maybeStop()
        }
        if (bound) {
            try {
                unbindService(connection)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            bound = false
        }
        service = null
        super.onDestroy()
    }

    override fun onChanged() {
        refreshUi()
    }

    // ------------------------------------------------------------------ kurulum

    private fun bindViews() {
        nav = findViewById(R.id.bottom_nav)
        pageHome = findViewById(R.id.page_home)
        pagePlayer = findViewById(R.id.page_player)
        pageSettings = findViewById(R.id.page_settings)

        rv = findViewById(R.id.rv_songs)
        fab = findViewById(R.id.fab_add)
        emptyBox = findViewById(R.id.empty_box)
        tvEmpty = findViewById(R.id.tv_empty)
        btnGrant = findViewById(R.id.btn_grant)
        tvCount = findViewById(R.id.tv_count)

        ivArt = findViewById(R.id.iv_art)
        tvTitle = findViewById(R.id.tv_title)
        tvArtist = findViewById(R.id.tv_artist)
        seek = findViewById(R.id.seek)
        tvPos = findViewById(R.id.tv_pos)
        tvDur = findViewById(R.id.tv_dur)
        btnRew = findViewById(R.id.btn_rew)
        btnFwd = findViewById(R.id.btn_fwd)
        btnPrev = findViewById(R.id.btn_prev)
        btnPlay = findViewById(R.id.btn_play)
        btnNext = findViewById(R.id.btn_next)
        btnShuffle = findViewById(R.id.btn_shuffle)
        btnRepeat = findViewById(R.id.btn_repeat)
        btnSpeed = findViewById(R.id.btn_speed)
        btnSleep = findViewById(R.id.btn_sleep)
        seekVol = findViewById(R.id.seek_volume)
        swOverlay = findViewById(R.id.sw_overlay)

        rgLang = findViewById(R.id.rg_lang)
        rbTr = findViewById(R.id.rb_tr)
        rbEn = findViewById(R.id.rb_en)
        rowAccess = findViewById(R.id.row_access)
        tvVersion = findViewById(R.id.tv_version)
    }

    private fun showTab(i: Int) {
        tab = i
        pageHome.visibility = if (i == 0) View.VISIBLE else View.GONE
        pagePlayer.visibility = if (i == 1) View.VISIBLE else View.GONE
        pageSettings.visibility = if (i == 2) View.VISIBLE else View.GONE
    }

    private fun setupHome() {
        adapter = SongAdapter(
            onClick = { song -> playFromList(song) },
            onLongClick = { song -> confirmRemove(song) }
        )
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        fab.setOnClickListener { pickLauncher.launch(arrayOf("audio/*")) }
        btnGrant.setOnClickListener { onGrantClick() }
        updateEmpty()
    }

    private fun setupPlayer() {
        tvTitle.text = getString(R.string.nothing_playing)
        btnPlay.setOnClickListener { service?.toggle() }
        btnNext.setOnClickListener { service?.next() }
        btnPrev.setOnClickListener { service?.prev() }
        btnRew.setOnClickListener { service?.skip(-10000) }
        btnFwd.setOnClickListener { service?.skip(10000) }
        btnShuffle.setOnClickListener { service?.toggleShuffle() }
        btnRepeat.setOnClickListener { service?.cycleRepeat() }
        btnSpeed.setOnClickListener { service?.cycleSpeed() }
        btnSleep.setOnClickListener { showSleepDialog() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tvPos.text = formatTime(progress.toLong())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                userSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                service?.seekTo(seekBar?.progress ?: 0)
                userSeeking = false
            }
        })

        seekVol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) service?.setVolume(progress / 100f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        swOverlay.setOnCheckedChangeListener { _, checked ->
            if (!updatingUi) onOverlaySwitch(checked)
        }
    }

    private fun setupSettings() {
        val lang = LocaleHelper.lang(this)
        rbTr.isChecked = lang == "tr"
        rbEn.isChecked = lang != "tr"
        rgLang.setOnCheckedChangeListener { _, checkedId ->
            val code = if (checkedId == R.id.rb_en) "en" else "tr"
            if (code != LocaleHelper.lang(this)) {
                LocaleHelper.save(this, code)
                service?.onLanguageChanged()
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
            }
        }

        rowAccess.setOnClickListener { openAppSettings() }
        tvVersion.text = getString(R.string.version_fmt, versionName())
    }

    private fun versionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    // ------------------------------------------------------------------ izinler

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.READ_MEDIA_AUDIO)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            loadLibrary()
        } else {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    private fun onGrantClick() {
        val perm = Library.audioPermission()
        if (prefs.getBoolean("perm_asked", false) && !shouldShowRequestPermissionRationale(perm)) {
            openAppSettings()
        } else {
            askPermissions()
        }
    }

    private fun openAppSettings() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        try {
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e2: Exception) {
                e2.printStackTrace()
            }
        }
    }

    private fun onOverlaySwitch(checked: Boolean) {
        val s = service
        if (checked) {
            if (Settings.canDrawOverlays(this)) {
                s?.setBubbleEnabled(true)
            } else {
                // izin yok: ayar ekranına gönder, döndüğünde onResume'da açılacak
                pendingOverlay = true
                updatingUi = true
                swOverlay.isChecked = false
                updatingUi = false
                Toast.makeText(this, R.string.overlay_permission_needed, Toast.LENGTH_LONG).show()
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    pendingOverlay = false
                    openAppSettings()
                }
            }
        } else {
            s?.setBubbleEnabled(false)
        }
    }

    // ------------------------------------------------------------------ müzik listesi

    private fun loadLibrary() {
        val app = applicationContext
        Thread {
            val list = Library.load(app)
            runOnUiThread {
                if (!isDestroyed) {
                    if (list != adapter.items) adapter.submit(list)
                    updateEmpty()
                }
            }
        }.start()
    }

    private fun updateEmpty() {
        val n = adapter.items.size
        tvCount.text = getString(R.string.song_count, n)
        if (n > 0) {
            emptyBox.visibility = View.GONE
        } else {
            emptyBox.visibility = View.VISIBLE
            if (!Library.hasAudioPermission(this)) {
                tvEmpty.setText(R.string.perm_needed)
                btnGrant.visibility = View.VISIBLE
            } else {
                tvEmpty.setText(R.string.empty_no_songs)
                btnGrant.visibility = View.GONE
            }
        }
    }

    private fun addSongs(uris: List<Uri>) {
        val app = applicationContext
        Thread {
            val n = Library.addSongs(app, uris)
            val list = Library.load(app)
            runOnUiThread {
                if (!isDestroyed) {
                    adapter.submit(list)
                    updateEmpty()
                    val msg = if (n > 0) getString(R.string.songs_added, n) else getString(R.string.songs_none_added)
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun playFromList(song: Song) {
        service?.playSong(song)
        nav.selectedItemId = R.id.nav_player
    }

    private fun confirmRemove(song: Song) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.remove_title)
            .setMessage(getString(R.string.remove_msg, song.title))
            .setPositiveButton(R.string.remove) { _, _ ->
                val app = applicationContext
                Thread {
                    Library.removeAdded(app, song.uri)
                    val list = Library.load(app)
                    runOnUiThread {
                        if (!isDestroyed) {
                            adapter.submit(list)
                            updateEmpty()
                        }
                    }
                }.start()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showSleepDialog() {
        val s = service ?: return
        val mins = intArrayOf(0, 15, 30, 45, 60, 90)
        val labels = Array(mins.size) { i ->
            if (mins[i] == 0) getString(R.string.sleep_off) else getString(R.string.sleep_minutes, mins[i])
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.sleep_title)
            .setItems(labels) { _, which ->
                val m = mins[which]
                s.setSleepTimer(m)
                val msg = if (m == 0) getString(R.string.sleep_cancelled) else getString(R.string.sleep_set, m)
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    // ------------------------------------------------------------------ arayüz güncelleme

    private val ticker = object : Runnable {
        override fun run() {
            val s = service
            if (s != null && !userSeeking) {
                val dur = s.duration()
                val max = if (dur > 0) dur else 1
                if (seek.max != max) seek.max = max
                val pos = s.position()
                seek.progress = pos
                tvPos.text = formatTime(pos.toLong())
                tvDur.text = formatTime(dur.toLong())
            }
            ui.postDelayed(this, 500)
        }
    }

    private fun tint(v: ImageView, on: Boolean) {
        val c = ContextCompat.getColor(this, if (on) R.color.accent else R.color.text_secondary)
        v.imageTintList = ColorStateList.valueOf(c)
    }

    private fun speedText(sp: Float): String {
        val t = if (sp == sp.toInt().toFloat()) sp.toInt().toString() else sp.toString()
        return t + "x"
    }

    private fun refreshUi() {
        val s = service ?: return
        val song = s.current

        tvTitle.text = song?.title ?: getString(R.string.nothing_playing)
        tvArtist.text = if (song != null) song.displayArtist(this) else ""

        val art = s.art
        if (ivArt.tag !== art) {
            ivArt.tag = art
            if (art != null) ivArt.setImageBitmap(art) else ivArt.setImageResource(R.drawable.cover)
        }

        btnPlay.setImageResource(if (s.playing) R.drawable.ic_pause else R.drawable.ic_play)

        tint(btnShuffle, s.shuffle)
        btnRepeat.setImageResource(
            if (s.repeatMode == PlayerService.REPEAT_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat
        )
        tint(btnRepeat, s.repeatMode != PlayerService.REPEAT_OFF)
        btnSpeed.text = speedText(s.speed)
        btnSpeed.setTextColor(
            ContextCompat.getColor(this, if (s.speed != 1.0f) R.color.accent else R.color.text_secondary)
        )
        tint(btnSleep, s.sleepActive())

        val vp = (s.volume * 100).roundToInt()
        if (seekVol.progress != vp) seekVol.progress = vp

        updatingUi = true
        swOverlay.isChecked = s.bubbleEnabled
        updatingUi = false

        adapter.setCurrent(song?.uri)
    }
}
