package com.sw.muzikoynatici

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

data class Song(
    val uri: String,
    val title: String,
    val artist: String,
    val duration: Long,
    val name: String,
    val size: Long,
    val added: Boolean
)

fun Song.displayArtist(ctx: Context): String =
    if (artist.isBlank()) ctx.getString(R.string.unknown_artist) else artist

fun formatTime(ms: Long): String {
    val t = if (ms < 0) 0L else ms / 1000
    return String.format(Locale.US, "%d:%02d", t / 60, t % 60)
}

object LocaleHelper {
    private const val PREF = "sw_prefs"

    /** Seçili dil: "tr" veya "en". Hiç seçilmediyse telefonun diline bakar. */
    fun lang(ctx: Context): String {
        val saved = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("lang", null)
        if (saved != null) return saved
        return if (Locale.getDefault().language == "tr") "tr" else "en"
    }

    fun save(ctx: Context, code: String) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("lang", code).apply()
    }

    /** Servis / bildirim metinleri için seçili dile göre context üretir. */
    fun wrap(ctx: Context): Context {
        val cfg = Configuration(ctx.resources.configuration)
        cfg.setLocale(Locale.forLanguageTag(lang(ctx)))
        return ctx.createConfigurationContext(cfg)
    }
}
