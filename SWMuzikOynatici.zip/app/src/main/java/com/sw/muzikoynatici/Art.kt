package com.sw.muzikoynatici

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** MP3 içindeki kapak resmini okur (liste, oynatıcı, baloncuk ve bildirim için). */
object Art {

    private class Entry(val bmp: Bitmap?)

    private val cache = object : LruCache<String, Entry>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Entry): Int =
            (value.bmp?.byteCount ?: 0) + 64
    }

    private val executor: ExecutorService = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    /** Sonuç her zaman ana thread'de [cb] ile döner. Kapak yoksa null gelir. */
    fun load(ctx: Context, uri: String, max: Int, cb: (Bitmap?) -> Unit) {
        val key = "$uri#$max"
        val hit = cache.get(key)
        if (hit != null) {
            cb(hit.bmp)
            return
        }
        val app = ctx.applicationContext
        executor.execute {
            val bmp = decode(app, uri, max)
            cache.put(key, Entry(bmp))
            main.post { cb(bmp) }
        }
    }

    private fun decode(ctx: Context, uri: String, max: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, Uri.parse(uri))
            val bytes = r.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= max && bounds.outHeight / (sample * 2) >= max) {
                sample *= 2
            }
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: Throwable) {
            return null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }
}
