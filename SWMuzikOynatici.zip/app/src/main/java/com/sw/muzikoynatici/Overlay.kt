package com.sw.muzikoynatici

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Point
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Diğer uygulamaların üstünde görünen sürüklenebilir müzik baloncuğu
 * ve baloncuğa tıklanınca yanında açılan küçük kontrol paneli.
 */
class Overlay(private val svc: PlayerService) {

    private val ctx: Context = ContextThemeWrapper(svc.applicationContext, R.style.AppTheme)
    private val wm: WindowManager = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = svc.getSharedPreferences("sw_prefs", Context.MODE_PRIVATE)
    private val density: Float = ctx.resources.displayMetrics.density

    private val windowFlags: Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private var bubble: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bubbleImg: ImageView? = null

    private var panel: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelOpen = false
    private var panelAttached = false

    private var panelArt: ImageView? = null
    private var panelTitle: TextView? = null
    private var panelPlay: ImageView? = null
    private var panelVolume: SeekBar? = null

    private fun dp(v: Int): Int = (v * density).roundToInt()

    private fun inflate(layout: Int): View =
        LayoutInflater.from(ctx).inflate(layout, null) as View

    @Suppress("DEPRECATION")
    private fun screen(): Point {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        return p
    }

    private fun clamp(lp: WindowManager.LayoutParams, size: Int) {
        val s = screen()
        lp.x = lp.x.coerceIn(0, max(0, s.x - size))
        lp.y = lp.y.coerceIn(0, max(0, s.y - size))
    }

    // ------------------------------------------------------------------ baloncuk

    fun show() {
        if (bubble != null) {
            refresh()
            return
        }
        val v: View = inflate(R.layout.overlay_bubble)
        val size = dp(64)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            windowFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val s = screen()
        lp.x = prefs.getInt("bubble_x", s.x - size - dp(8))
        lp.y = prefs.getInt("bubble_y", s.y / 3)
        clamp(lp, size)
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            e.printStackTrace()
            return
        }
        bubble = v
        bubbleLp = lp
        bubbleImg = v.findViewById(R.id.bubble_img)
        v.setOnTouchListener(DragListener())
        refresh()
    }

    fun hide() {
        closePanel()
        panel = null
        panelArt = null
        panelTitle = null
        panelPlay = null
        panelVolume = null
        val b = bubble
        if (b != null) {
            try {
                wm.removeView(b)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        bubble = null
        bubbleLp = null
        bubbleImg = null
    }

    private inner class DragListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var downX = 0f
        private var downY = 0f
        private var moved = false
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val lp = bubbleLp ?: return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    downX = e.rawX
                    downY = e.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = (startX + dx).toInt()
                        lp.y = (startY + dy).toInt()
                        clamp(lp, lp.width)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (ex: Exception) {
                            ex.printStackTrace()
                        }
                        if (panelOpen) positionPanel()
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("bubble_x", lp.x).putInt("bubble_y", lp.y).apply()
                    } else {
                        togglePanel()
                    }
                    return true
                }
                MotionEvent.ACTION_CANCEL -> return true
            }
            return false
        }
    }

    // ------------------------------------------------------------------ panel

    private fun togglePanel() {
        if (panelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        if (bubble == null) return
        val existing = panel
        val p: View
        if (existing != null) {
            p = existing
        } else {
            p = inflate(R.layout.overlay_panel)
            setupPanel(p)
            panel = p
        }
        val lp = WindowManager.LayoutParams(
            dp(250),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            windowFlags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        panelLp = lp
        refresh()
        computePanelPosition(p, lp)
        try {
            wm.addView(p, lp)
            panelAttached = true
            panelOpen = true
        } catch (e: Exception) {
            e.printStackTrace()
            panelAttached = false
            panelOpen = false
        }
    }

    private fun closePanel() {
        val p = panel
        if (p != null && panelAttached) {
            try {
                wm.removeView(p)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        panelAttached = false
        panelOpen = false
    }

    private fun setupPanel(p: View) {
        panelArt = p.findViewById(R.id.panel_art)
        panelTitle = p.findViewById(R.id.panel_title)
        panelPlay = p.findViewById(R.id.panel_play)
        panelVolume = p.findViewById(R.id.panel_volume)

        panelTitle?.isSelected = true // kayan yazı (marquee) için

        p.findViewById<View>(R.id.panel_rew).setOnClickListener { svc.skip(-10000) }
        p.findViewById<View>(R.id.panel_fwd).setOnClickListener { svc.skip(10000) }
        p.findViewById<View>(R.id.panel_play).setOnClickListener { svc.toggle() }
        p.findViewById<View>(R.id.panel_next).setOnClickListener { svc.next() }
        p.findViewById<View>(R.id.panel_close).setOnClickListener { svc.setBubbleEnabled(false) }

        panelVolume?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) svc.setVolume(progress / 100f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    /** Paneli baloncuğun yanına yerleştirir: baloncuk ekranın solundaysa sağına, sağındaysa soluna. */
    private fun computePanelPosition(p: View, lp: WindowManager.LayoutParams) {
        val b = bubbleLp ?: return
        val s = screen()
        val pw = dp(250)
        p.measure(
            View.MeasureSpec.makeMeasureSpec(pw, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val ph = p.measuredHeight
        val gap = dp(8)
        val bubbleCenter = b.x + b.width / 2
        var x = if (bubbleCenter < s.x / 2) b.x + b.width + gap else b.x - pw - gap
        x = x.coerceIn(0, max(0, s.x - pw))
        val y = b.y.coerceIn(0, max(0, s.y - ph))
        lp.x = x
        lp.y = y
    }

    private fun positionPanel() {
        val p = panel ?: return
        val lp = panelLp ?: return
        computePanelPosition(p, lp)
        if (panelAttached) {
            try {
                wm.updateViewLayout(p, lp)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ------------------------------------------------------------------ güncelleme

    /** Çalan müziğe göre baloncuk resmini, panel yazısını, tuşları ve ses çubuğunu günceller. */
    fun refresh() {
        val art = svc.art

        val bi = bubbleImg
        if (bi != null && bi.tag !== art) {
            bi.tag = art
            if (art != null) bi.setImageBitmap(art) else bi.setImageResource(R.drawable.cover)
        }

        val pa = panelArt
        if (pa != null && pa.tag !== art) {
            pa.tag = art
            if (art != null) pa.setImageBitmap(art) else pa.setImageResource(R.drawable.cover)
        }

        val pt = panelTitle
        if (pt != null) {
            val title = svc.current?.title ?: ctx.getString(R.string.app_name)
            if (pt.text.toString() != title) pt.text = title
        }

        panelPlay?.setImageResource(if (svc.playing) R.drawable.ic_pause else R.drawable.ic_play)

        val pv = panelVolume
        if (pv != null) {
            val vp = (svc.volume * 100).roundToInt()
            if (pv.progress != vp) pv.progress = vp
        }
    }

    fun onConfigChanged() {
        val lp = bubbleLp ?: return
        val b = bubble ?: return
        clamp(lp, lp.width)
        try {
            wm.updateViewLayout(b, lp)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (panelOpen) positionPanel()
    }
}
